(function() {
    bhNodeHandler.deleteNode(bhThis, bhUserOpeCmd);
})();
