(function() {
	return 'StrList' === bhReplacedNewNode.getSymbolName();
})();