(function() {
	return ['pscp', '-pw', password, bhProgramFilePath, (uname + '@' + ipAddr + ':' + 'BunnyHop/Compiled/')];
})();
