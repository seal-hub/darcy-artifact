(function() {
	return bhReplacedNewNode.getSymbolName() === "NumVar";
})();
